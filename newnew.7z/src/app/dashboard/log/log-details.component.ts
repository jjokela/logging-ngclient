import { Component, OnInit, InjectionToken, ViewChild, Inject, HostListener } from '@angular/core';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { MdlTextFieldComponent } from '@angular-mdl/core';
import { MdlDialogReference } from '@angular-mdl/core';
export const TEST_VALUE = new InjectionToken<string>('test value');

@Component({
    selector: 'app-log-details',
    templateUrl: 'log-details.component.html',
    styleUrls: ['log-details.component.css']
})

export class LogDetailsComponent implements OnInit {

    // @ViewChild('firstElement') private inputElement: MdlTextFieldComponent;
    public form: FormGroup;
    public username = new FormControl('', Validators.required);
    public password = new FormControl('', Validators.required);

    public processingLogin = false;
    public statusMessage = '';

    constructor(
        private dialog: MdlDialogReference,
        private fb: FormBuilder,
        // private loginService: LoginService,
        @Inject(TEST_VALUE) testValue: string) {

        console.log(`injected test value: ${testValue}`);

        // just if you want to be informed if the dialog is hidden
        this.dialog.onHide().subscribe((user) => {
            console.log('login dialog hidden');
            if (user) {
                console.log('authenticated user', user);
            }
        });

        this.dialog.onVisible().subscribe(() => {
            console.log('set focus');
            // this.inputElement.setFocus();
        });

    }


    public ngOnInit() {
        this.form = this.fb.group({
            'username': this.username,
            'password': this.password
        });
    }


    public close() {
        this.dialog.hide();
    }

    public dismiss() {
        this.dialog.hide();
    }

    public login() {
        this.processingLogin = true;
        this.statusMessage = 'checking your credentials ...';

        // let obs = this.loginService.login(this.username.value, this.password.value);
        // obs.subscribe( user => {

        this.processingLogin = false;
        this.statusMessage = 'you are logged in ...';

        setTimeout(() => {
            this.dialog.hide();
        }, 500);

        // });
    }

    @HostListener('keydown.esc')
    public onEsc(): void {
        this.dialog.hide();
    }
}
