import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-filter-buttons',
    templateUrl: 'filter-buttons.component.html',
    styleUrls: ['filter-buttons.component.css']
})

export class FilterButtonsComponent implements OnInit {

    infoSelected = true;
    errorSelected = true;
    warningSelected = true;
    successSelected = true;

    constructor() { }

    ngOnInit() { }

    infoClicked() {
        this.infoSelected = !this.infoSelected;
    }

    errorClicked() {
        this.errorSelected = !this.errorSelected;
    }

    successClicked() {
        this.successSelected = !this.successSelected;
    }

    warningClicked() {
        this.warningSelected = !this.warningSelected;
    }
}
